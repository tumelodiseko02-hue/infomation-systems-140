import os
import sqlite3
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
LOCAL_DB = BASE_DIR / "canola.db"

TABLES_IN_ORDER = [
    "trials",
    "trial_sites",
    "treatments",
    "plots",
    "assessment_traits",
    "assessment_data",
    "measurements",
]

def connect_local():
    conn = sqlite3.connect(LOCAL_DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def setup_local_database():
    """Create the local SQLite database used for offline work."""
    with connect_local() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS trials (
            trial_id INTEGER PRIMARY KEY AUTOINCREMENT,
            trial_code TEXT UNIQUE,
            trial_name TEXT,
            objective TEXT,
            target_crop TEXT,
            trial_start_date TEXT,
            trial_end_date TEXT,
            status TEXT,
            created_at TEXT
        );

        CREATE TABLE IF NOT EXISTS trial_sites (
            site_id INTEGER PRIMARY KEY AUTOINCREMENT,
            trial_id INTEGER,
            site_name TEXT,
            latitude REAL,
            longitude REAL,
            soil_type TEXT,
            previous_crop TEXT,
            experimental_design TEXT,
            number_of_replicates INTEGER,
            FOREIGN KEY (trial_id) REFERENCES trials(trial_id)
        );

        CREATE TABLE IF NOT EXISTS treatments (
            treatment_id INTEGER PRIMARY KEY AUTOINCREMENT,
            trial_id INTEGER,
            treatment_number INTEGER,
            treatment_name TEXT,
            formulation_details TEXT,
            application_rate REAL,
            rate_unit TEXT,
            FOREIGN KEY (trial_id) REFERENCES trials(trial_id)
        );

        CREATE TABLE IF NOT EXISTS plots (
            plot_id INTEGER PRIMARY KEY AUTOINCREMENT,
            site_id INTEGER,
            plot_number INTEGER,
            replicate_number INTEGER,
            treatment_id INTEGER,
            row_index INTEGER,
            column_index INTEGER,
            FOREIGN KEY (site_id) REFERENCES trial_sites(site_id),
            FOREIGN KEY (treatment_id) REFERENCES treatments(treatment_id)
        );

        CREATE TABLE IF NOT EXISTS assessment_traits (
            trait_id INTEGER PRIMARY KEY AUTOINCREMENT,
            trial_id INTEGER,
            trait_name TEXT,
            methodology TEXT,
            unit_of_measurement TEXT,
            data_type TEXT,
            FOREIGN KEY (trial_id) REFERENCES trials(trial_id)
        );

        CREATE TABLE IF NOT EXISTS assessment_data (
            data_id INTEGER PRIMARY KEY AUTOINCREMENT,
            trait_id INTEGER,
            plot_id INTEGER,
            numeric_value REAL,
            assessment_date TEXT,
            text_value TEXT,
            collected_by TEXT,
            notes TEXT,
            FOREIGN KEY (trait_id) REFERENCES assessment_traits(trait_id),
            FOREIGN KEY (plot_id) REFERENCES plots(plot_id)
        );

        CREATE TABLE IF NOT EXISTS measurements (
            measurement_id INTEGER PRIMARY KEY AUTOINCREMENT,
            plot_id INTEGER,
            measurement_type TEXT,
            value REAL,
            measurement_date TEXT,
            FOREIGN KEY (plot_id) REFERENCES plots(plot_id)
        );
        """)
    print(f"Local database ready: {LOCAL_DB}")

def add_sample_data():
    """Add the example canola trial once, for demonstration."""
    with connect_local() as conn:
        existing = conn.execute(
            "SELECT trial_id FROM trials WHERE trial_code = ?", ("CAN2026",)
        ).fetchone()
        if existing:
            print("Sample trial CAN2026 already exists; sample data was not duplicated.")
            return

        cur = conn.execute("""
            INSERT INTO trials
            (trial_code, trial_name, objective, target_crop, trial_start_date,
             trial_end_date, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "CAN2026",
            "Canola Growth Trial 2026",
            "Evaluate growth and yield of canola under different treatments",
            "Canola",
            "2026-09-01",
            "2026-12-15",
            "Ongoing",
            datetime.now().isoformat(timespec="seconds"),
        ))
        trial_id = cur.lastrowid

        control_id = conn.execute("""
            INSERT INTO treatments
            (trial_id, treatment_number, treatment_name, formulation_details,
             application_rate, rate_unit)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (trial_id, 1, "Control", "Untreated check", 0.0, "none")).lastrowid

        treatment_a_id = conn.execute("""
            INSERT INTO treatments
            (trial_id, treatment_number, treatment_name, formulation_details,
             application_rate, rate_unit)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (trial_id, 2, "Treatment A", "Fungicide treatment", 1.25, "L/ha")).lastrowid

        site_id = conn.execute("""
            INSERT INTO trial_sites
            (trial_id, site_name, latitude, longitude, soil_type, previous_crop,
             experimental_design, number_of_replicates)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (trial_id, "North Field",  -33.925, 18.424, "Loam", "Wheat", "RCBD", 4)).lastrowid

        plot_ids = []
        # Four plots per replicate, with treatment assigned in alternating pattern.
        for replicate in range(1, 5):
            for plot_number in range(1, 5):
                treatment_id = control_id if (plot_number + replicate) % 2 == 0 else treatment_a_id
                plot_id = conn.execute("""
                    INSERT INTO plots
                    (site_id, plot_number, replicate_number, treatment_id, row_index, column_index)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (site_id, plot_number, replicate, treatment_id, replicate, plot_number)).lastrowid
                plot_ids.append(plot_id)

        traits = [
            ("Plant Height", "Measured from base to highest point", "cm", "numeric"),
            ("Canopy Cover", "Visual field estimate", "%", "numeric"),
            ("Yield", "Harvested plot weight", "kg/ha", "numeric"),
        ]
        trait_ids = []
        for name, method, unit, data_type in traits:
            trait_ids.append(conn.execute("""
                INSERT INTO assessment_traits
                (trial_id, trait_name, methodology, unit_of_measurement, data_type)
                VALUES (?, ?, ?, ?, ?)
            """, (trial_id, name, method, unit, data_type)).lastrowid)

        examples = [
            (trait_ids[0], plot_ids[0], 45.5, "2026-10-05", None, "A. Farmer", "Initial height assessment"),
            (trait_ids[1], plot_ids[0], 72.3, "2026-10-05", None, "A. Farmer", "Canopy cover check"),
            (trait_ids[2], plot_ids[0], 3010.0, "2026-12-15", None, "A. Farmer", "Final harvest yield"),
        ]
        conn.executemany("""
            INSERT INTO assessment_data
            (trait_id, plot_id, numeric_value, assessment_date, text_value, collected_by, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, examples)

    print("Sample canola trial added.")

def show_trials():
    with connect_local() as conn:
        rows = conn.execute("""
            SELECT trial_id, trial_code, trial_name, target_crop, status,
                   trial_start_date, trial_end_date
            FROM trials ORDER BY trial_id
        """).fetchall()
    if not rows:
        print("\nNo trials saved yet.")
        return
    print("\nTRIALS")
    print("-" * 92)
    for r in rows:
        print(f"ID: {r['trial_id']} | Code: {r['trial_code']} | {r['trial_name']} | "
              f"Crop: {r['target_crop']} | Status: {r['status']} | "
              f"{r['trial_start_date']} to {r['trial_end_date']}")

def show_plots():
    with connect_local() as conn:
        rows = conn.execute("""
            SELECT p.plot_id, s.site_name, p.plot_number, p.replicate_number,
                   t.treatment_name, p.row_index, p.column_index
            FROM plots p
            LEFT JOIN trial_sites s ON s.site_id = p.site_id
            LEFT JOIN treatments t ON t.treatment_id = p.treatment_id
            ORDER BY p.replicate_number, p.plot_number
        """).fetchall()
    if not rows:
        print("\nNo plots saved yet.")
        return
    print("\nPLOTS")
    print("-" * 92)
    for r in rows:
        print(f"Plot ID: {r['plot_id']} | Site: {r['site_name']} | Plot: {r['plot_number']} | "
              f"Replicate: {r['replicate_number']} | Treatment: {r['treatment_name']} | "
              f"Row: {r['row_index']} | Column: {r['column_index']}")

def show_assessments():
    with connect_local() as conn:
        rows = conn.execute("""
            SELECT ad.data_id, tr.trait_name, p.plot_number, p.replicate_number,
                   ad.numeric_value, tr.unit_of_measurement, ad.assessment_date,
                   ad.collected_by, ad.notes
            FROM assessment_data ad
            LEFT JOIN assessment_traits tr ON tr.trait_id = ad.trait_id
            LEFT JOIN plots p ON p.plot_id = ad.plot_id
            ORDER BY ad.data_id
        """).fetchall()
    if not rows:
        print("\nNo assessment data saved yet.")
        return
    print("\nASSESSMENT DATA")
    print("-" * 92)
    for r in rows:
        print(f"ID: {r['data_id']} | Trait: {r['trait_name']} | Plot: {r['plot_number']} "
              f"(Replicate {r['replicate_number']}) | Value: {r['numeric_value']} "
              f"{r['unit_of_measurement']} | Date: {r['assessment_date']} | "
              f"Collected by: {r['collected_by']} | Notes: {r['notes']}")

def record_assessment():
    try:
        plot_id = int(input("Plot ID: ").strip())
        trait_id = int(input("Trait ID (see assessment list/database): ").strip())
        value = float(input("Numeric result: ").strip())
        assessment_date = input("Assessment date (YYYY-MM-DD): ").strip()
        collected_by = input("Collected by: ").strip()
        notes = input("Notes (optional): ").strip()
        datetime.strptime(assessment_date, "%Y-%m-%d")
        with connect_local() as conn:
            plot_exists = conn.execute("SELECT 1 FROM plots WHERE plot_id=?", (plot_id,)).fetchone()
            trait_exists = conn.execute("SELECT 1 FROM assessment_traits WHERE trait_id=?", (trait_id,)).fetchone()
            if not plot_exists or not trait_exists:
                print("That plot ID or trait ID does not exist. No record was saved.")
                return
            conn.execute("""
                INSERT INTO assessment_data
                (trait_id, plot_id, numeric_value, assessment_date, text_value, collected_by, notes)
                VALUES (?, ?, ?, ?, NULL, ?, ?)
            """, (trait_id, plot_id, value, assessment_date, collected_by, notes))
        print("Assessment saved locally. It can be synced when internet is available.")
    except ValueError:
        print("Please enter valid numbers and use a date like 2026-10-15.")

def show_traits():
    with connect_local() as conn:
        rows = conn.execute("""
            SELECT trait_id, trait_name, unit_of_measurement, methodology
            FROM assessment_traits ORDER BY trait_id
        """).fetchall()
    print("\nASSESSMENT TRAITS")
    print("-" * 70)
    if not rows:
        print("No traits found.")
    for r in rows:
        print(f"Trait ID: {r['trait_id']} | {r['trait_name']} ({r['unit_of_measurement']}) - {r['methodology']}")

def sync_to_supabase():
    """
    Upload local rows to Supabase in foreign-key order.
    Set SUPABASE_DB_URL to your Supabase PostgreSQL connection string first.
    This starter sync uses matching primary-key IDs and is suitable for a single
    app/device demonstration. Multi-device conflict resolution needs extra design.
    """
    db_url = os.getenv("SUPABASE_DB_URL")
    if not db_url:
        print("\nSupabase sync not configured.")
        print("Set the SUPABASE_DB_URL environment variable using your Supabase PostgreSQL connection string.")
        print("Your local data remains saved in canola.db.")
        return

    try:
        import psycopg
        from psycopg import sql
    except ImportError:
        print("PostgreSQL driver missing. Run: pip install -r requirements.txt")
        return

    pk_columns = {
        "trials": "trial_id",
        "trial_sites": "site_id",
        "treatments": "treatment_id",
        "plots": "plot_id",
        "assessment_traits": "trait_id",
        "assessment_data": "data_id",
        "measurements": "measurement_id",
    }

    try:
        with connect_local() as local, psycopg.connect(db_url) as remote:
            for table in TABLES_IN_ORDER:
                pk = pk_columns[table]
                rows = local.execute(f"SELECT * FROM {table} ORDER BY {pk}").fetchall()
                if not rows:
                    continue
                columns = list(rows[0].keys())
                for row in rows:
                    values = [row[col] for col in columns]
                    insert_stmt = sql.SQL("INSERT INTO public.{} ({}) VALUES ({}) ON CONFLICT ({}) DO UPDATE SET {}").format(
                        sql.Identifier(table),
                        sql.SQL(", ").join(map(sql.Identifier, columns)),
                        sql.SQL(", ").join(sql.Placeholder() for _ in columns),
                        sql.Identifier(pk),
                        sql.SQL(", ").join(
                            sql.SQL("{} = EXCLUDED.{}").format(sql.Identifier(col), sql.Identifier(col))
                            for col in columns if col != pk
                        )
                    )
                    remote.execute(insert_stmt, values)
            remote.commit()
        print("Sync completed successfully. Local records were uploaded to Supabase.")
    except Exception as exc:
        print("\nSync did not complete.")
        print("Check the database URL, network connection, Supabase SQL setup, and error below:")
        print(f"{type(exc).__name__}: {exc}")
        print("Your local SQLite data has not been deleted.")

def main():
    setup_local_database()
    while True:
        print("""
================ AGritrial MVP ================
1. Add demonstration canola sample data
2. View trials
3. View plots
4. View assessment data
5. View assessment traits
6. Record a new assessment (works offline)
7. Sync local data to Supabase
0. Exit
===============================================
""")
        choice = input("Choose an option: ").strip()
        if choice == "1":
            add_sample_data()
        elif choice == "2":
            show_trials()
        elif choice == "3":
            show_plots()
        elif choice == "4":
            show_assessments()
        elif choice == "5":
            show_traits()
        elif choice == "6":
            record_assessment()
        elif choice == "7":
            sync_to_supabase()
        elif choice == "0":
            print("Goodbye. Your local data is saved.")
            break
        else:
            print("Invalid choice. Please choose 0 to 7.")

if __name__ == "__main__":
    main()
