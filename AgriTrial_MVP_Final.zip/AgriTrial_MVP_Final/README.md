# AgriTrial MVP — Final starter project

This Python MVP uses:
- **SQLite (`canola.db`)** for local/offline storage.
- **Supabase PostgreSQL** for an online copy of the records when a connection is available.
- A simple terminal menu for viewing trials, plots, assessment traits and assessment data, recording a new assessment, and syncing data.

## Files

- `app.py` — Python application.
- `supabase_schema.sql` — tables to create in Supabase.
- `requirements.txt` — PostgreSQL driver.
- `.env.example` — example connection-string format. Do not put real credentials in shared files.

## 1. Run locally first (offline mode)

Install Python 3.10 or newer. Open a terminal in this folder and run:

```bash
python app.py
```

The local `canola.db` file and tables are created automatically. Choose menu option **1** to add the demonstration canola trial. Choose **2–5** to view saved information and **6** to record a new assessment. These local features do not require internet.

## 2. Create Supabase tables

1. Sign in at https://supabase.com/ and create a project.
2. Open **SQL Editor** in the Supabase dashboard.
3. Open `supabase_schema.sql`, copy all its SQL, paste it into a new query, and run it.
4. In Supabase project connection settings, get the PostgreSQL connection string. Use the correct host and password for your project.

## 3. Install the PostgreSQL driver

```bash
python -m pip install -r requirements.txt
```

## 4. Configure the connection string

Set an environment variable called `SUPABASE_DB_URL`. Use your actual Supabase PostgreSQL connection string. Do not use the Supabase anon/public API key here.

### Windows PowerShell (for the current terminal only)

```powershell
$env:SUPABASE_DB_URL="postgresql://postgres:YOUR_PASSWORD@YOUR_HOST:5432/postgres"
python app.py
```

Replace the example password and host with the values from your Supabase project. If the password contains special URL characters, URL-encode it or use Supabase's provided connection string carefully.

### macOS/Linux (for the current terminal only)

```bash
export SUPABASE_DB_URL="postgresql://postgres:YOUR_PASSWORD@YOUR_HOST:5432/postgres"
python app.py
```

Then choose menu option **7** to sync local records to Supabase. If the connection is not configured or the internet is unavailable, your local records remain in SQLite.

## Important limitations / before production

- This is a student MVP, not a production-hardened deployment.
- The sync routine preserves local primary-key IDs and uploads tables in foreign-key order. It is intended for a single device/demo. Multiple devices can create conflicting IDs; a production version should use UUIDs, per-device IDs, and conflict-resolution rules.
- The schema must exist in Supabase before syncing.
- Database credentials are powerful secrets. Do not share them, commit them to source control, or place them in client-side code.
- Before exposing data through the Supabase Data API, enable and configure Row Level Security (RLS) and appropriate policies. Do not create unrestricted public write access.
- This starter does not yet have user login, a web dashboard, automatic background sync, deletion sync, or robust conflict resolution.
- `created_at` is text to match the local SQLite field in this starter. It can be changed to `TIMESTAMPTZ` later with a matching update in the Python app.
